

def geraldine(processor_data):
    content = processor_data["template_content_string"]
    return content